These data files contain a minimum example of measured and simulated gamma spectra. 
They can be used as-is to execute all functions of this software. 

Measured and simulated data for the isotopes Am241, Co60, Cs137 and Eu152 are included. 
In addition, there are pure (measured) background spectra and multi-class spectra (produced by superposition of different isotopes).
In our example, the simulated isotope spectra and the measured background will be used for training. 
All other data only serve as test data. 

The results are illustrative and not necessarily representative for the full performance of our software.
